local image
function love.load()
image = {love.graphics.newImage("mario_background.png"), love.graphics.newImage("mario_cloud.png"), love.graphics.newImage("mario_ground.png"), love.graphics.newImage("mario_pipe.png")}
end

function love.update()
  love.graphics.
end

function love.draw()
  love.graphics.setBackgroundColor(135,206,235)
  for(i=1,4) do
    if (i==1) then
      for j=0,3
        love.graphics.draw(image[i], -5, 200)
      end
    elseif
    end
  end
end
