Option = {}
local images = {love.graphics.newImage("background.png"), love.graphics.newImage("option.png"), love.graphics.newImage("som.png"), love.graphics.newImage("mute.png"), love.graphics.newImage("fullscreen.png"), love.graphics.newImage("window.png"), love.graphics.newImage("back.png")}

function Option:new()
  option = {}
  setmetatable(option, {__index = Option})
end

function Option:update(mouseX)
  
end

function Option:draw()
end