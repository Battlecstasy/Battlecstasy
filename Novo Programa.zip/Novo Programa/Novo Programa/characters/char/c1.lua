local c1 = {}
local CirnoGravity = 0.8
local CirnoJump = 1.1 
local CirnoHP = 90
local CirnoAnimationFrame ={}
local CirnoAnimationTime = 0
local animationsize = {8,8,2,6,9,3,2,2,6,3,4,4,7,8,5,2,7,5,8,4,6,6,13,5,13,14,10,26,23,14,32}
local Cirno_count = 1
local anim_type=4
local CirnoState=0 --Estado da Cirno. 0 é normal, 1 é no ar, 2 é em hitstun, 3 é caido, 4 é guardando, 5 é atacando, 6 é atacando no ar, 7 é agachada, 8 é atacando agachada, 9 é dash
local StageHeight
local Charbx=400
local Charby
local CirnoXSpeed = 0
local CirnoYSpeed = 0
local sprite = 1
local sprite2 = 1
local GenericVariable = 0
local GenericVariableAtk = 0
local CirnoAttacktype = 0
local SpecialEffects =0
local SpecialEffectX =0
local SpecialEffectY =0
local EnemyState = 0
local Guardtype=0
local hitboxX=65
local hitboxY=80


function c1:new(pos_chao)
  for i=1,31 do
    CirnoAnimationFrame[i] = {}
    for j=1,animationsize[i] do
      CirnoAnimationFrame[i][j]=love.graphics.newImage("characters/char/Cirno/Cirnosprite/Cirno"..Cirno_count..".png")
      Cirno_count=Cirno_count+1
    end
  end
  StageHeight = pos_chao - CirnoAnimationFrame[anim_type][sprite]:getHeight() -- Alterado por pos_chao. Crie uma variável pos_chao na main e coloque assim: "cirno:new(pos_chao)"
  Charby = StageHeight
  Cirno_count=1
end

function CirnoWalkForward(dt)
  anim_type=1
  CirnoXSpeed=120
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 8 then
    sprite= 1
    CirnoXSpeed=0
  end
end

function CirnoWalkBackward(dt)
  CirnoAnimationTime=CirnoAnimationTime+dt
  anim_type=2
  CirnoXSpeed=-120
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 8 then
    sprite= 1
    CirnoXSpeed=0
  end
end

function CirnoStandUp(dt)
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  anim_type=3
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite= 1
    CirnoState=0
    GenericVariable=0
  end
end

function CirnoStand(dt)
  CirnoXSpeed=0
  anim_type=4
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 6 then
    sprite= 1
  end
end

function CirnoLanding(dt)
  CirnoXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  anim_type=6
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 3 then
    sprite= 1
    CirnoState=0
    GenericVariable=0
  end
end
function CirnoLandingOnGround(dt)
  anim_type=5
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 9 then
    sprite=9
    CirnoState=0
  end
end
function CirnoJumpForward(dt)
  if CirnoState==0 then
    CirnoYSpeed=-400
  end
  CirnoState=1
  anim_type=7
  CirnoXSpeed=120
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
    CirnoXSpeed=0
  end
end
function CirnoJumpBackward(dt)
  if CirnoState==0 then
    CirnoYSpeed=-400
  end
  CirnoState=1
  anim_type=8
  CirnoXSpeed=-120
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
    CirnoXSpeed=0
  end
end
function CirnoJump(dt)
  CirnoXSpeed=0
  if CirnoState==0 then
    CirnoYSpeed=-400
  end
  CirnoState=1
  anim_type=9
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 6 then
    sprite=6
  end
end
function CirnoHitLow(dt)
  CirnoState=2
  anim_type=11
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    sprite=1
    CirnoState=0
  end
end
function CirnoHitHigh(dt)
  CirnoState=2
  anim_type=12
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    sprite=1
    CirnoState=0
  end
end
function CirnoHitAir(dt)
  CirnoState=2
  anim_type=13
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 7 then
    sprite=7
  end
end
function CirnoGuard(dt)
  SpecialEffects=9
  SpecialEffectX=50
  if GenericVariable==0 then
    sprite2=5
    GenericVariable=1
  end
  CirnoState=4
  Guardtype=0
  CirnoXSpeed=0
  anim_type=14
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    if GenericVariable==0 then
      sprite2=5
      GenericVariable=1
    end
    sprite2=sprite2+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 and GenericVariable==1 then
    sprite=1
  end
  if sprite2>8 then
    sprite2=5
  end
  if love.keyboard.isDown("down") then
    CirnoCrouchGuard(dt)
  end
  if not love.keyboard.isDown("left") then
    GenericVariable=2
  end
  if sprite>3 then
    sprite=1
    sprite2=1
    CirnoState=0
    Guardtype=0
    SpecialEffects=0
    SpecialEffectX=0
    GenericVariable=0
  end
end
function CirnoGettingBackUp(dt)
  anim_type=15
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 5 then
    sprite=1
    CirnoState=0
  end
end
function CirnoFalling(dt)
  anim_type=16
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
  end
  if love.keyboard.isDown("right") then
    CirnoXSpeed=120
  elseif love.keyboard.isDown("left") then
    CirnoXSpeed=-120
  else CirnoXSpeed=0
  end
end
function CirnoDashForward(dt)
  CirnoState=9
  anim_type=17
  CirnoXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    CirnoXSpeed=240
  end
  if sprite > 6 and love.keyboard.isDown("d") and love.keyboard.isDown("right") then
    sprite=3
  elseif sprite>6 then
    CirnoXSpeed=0
  end
  if not love.keyboard.isDown("d") or not love.keyboard.isDown("right") then
    if sprite < 7 then
      sprite=7
    end
  end
  if sprite > 7 then
    sprite=1
    GenericVariable=0
    CirnoXSpeed=0
    CirnoState=0
  end
end
function CirnoDashBackward(dt)
  CirnoState=9
  anim_type=18
  CirnoXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=2
  end
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 0 then
    CirnoXSpeed=-240
  end
  if sprite > 4 and love.keyboard.isDown("d") and love.keyboard.isDown("left") then
    sprite=1
  elseif sprite>4 then
    CirnoXSpeed=0
  end
  if not love.keyboard.isDown("d") or not love.keyboard.isDown("left") then
    if sprite < 5 then
      sprite=5
    end
  end
  if sprite > 5 then
    sprite=1
    GenericVariable=0
    CirnoXSpeed=0
    CirnoState=0
  end
end
function CirnoCrouchGuard(dt)
  SpecialEffects=9
  if GenericVariable==0 then
    sprite2=5
    GenericVariable=1
  end
  SpecialEffectX=50
  CirnoState=4
  Guardtype=1
  CirnoXSpeed=0
  anim_type=19
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    sprite2=sprite2+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 and GenericVariable==1 then
    sprite=1
  end
  if sprite2>8 then
    sprite2=5
  end
  if not love.keyboard.isDown("left") then
    GenericVariable=2
  end
  if not love.keyboard.isDown("down") then
    CirnoGuard(dt)
  end
  if sprite>3 then
    sprite=1
    sprite2=1
    CirnoState=0
    Guardtype=0
    SpecialEffects=0
    SpecialEffectX=0
    GenericVariable=0
  end
end
function CirnoCrouch(dt)
  CirnoXSpeed=0
  CirnoState=7
  anim_type=20
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    sprite=4
  end
end
function CirnoNeutralWeak(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=1
  CirnoState=5
  anim_type=21
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.05 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 6 then
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoNeutralHeavy(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=3
  CirnoState=5
  anim_type=22
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    SpecialEffects=1
    sprite2=6
    GenericVariable=GenericVariable+5*dt
    CirnoXSpeed=500
  end
  if sprite > 5 then
    sprite = 5
  end
  if GenericVariable>3 then
    CirnoXSpeed=0
    SpecialEffects=0
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
  end
end
function CirnoNeutralMedium(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=2
  CirnoState=5
  anim_type=23
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite >3 then
    SpecialEffectX=25
    SpecialEffectY=-10
    SpecialEffects=3
    sprite2=12
  end
  if sprite >5 then
    SpecialEffects=0
  end
  if sprite > 11 then
    sprite=1
    sprite2=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
  end
end
function CirnoCrouchingWeak(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=1
  CirnoState=8
  anim_type=24
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.05 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 5 then
    sprite=4
    CirnoState=7
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoCrouchingMedium(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=2
  CirnoState=8
  anim_type=25
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.125 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite>=2 then
    SpecialEffects=4
    GenericVariable=GenericVariable+7.5*dt
    sprite2=11
    SpecialEffectX=110
    SpecialEffectY=40
    CirnoXSpeed=150
  end
  if not love.keyboard.isDown("x") then
    sprite=1
    CirnoState=7
    CirnoAttacktype=0
    GenericVariableAtk=0
    SpecialEffects=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
    CirnoXSpeed=0
  end
  if sprite>10 and love.keyboard.isDown("x") then
    sprite=2
  end
end
function CirnoCrouchingHeavy(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=3
  CirnoState=8
  anim_type=26
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite >3 then
    SpecialEffects=2
    SpecialEffectY=-80
    sprite2=14
    CirnoXSpeed=100
    GenericVariable=GenericVariable+2*dt
    if GenericVariable<1 and sprite>8 then
      sprite=8
    end
  end
  if sprite==6 then
    SpecialEffectX=60
    SpecialEffectY=-60
  end
  if sprite>6 then
    SpecialEffectX=80
    SpecialEffectY=0
  end
  if sprite>8 then
    CirnoXSpeed=0
    SpecialEffects=0
  end
  if sprite > 13 then
    sprite=1
    CirnoState=7
    CirnoAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
  end
end
function CirnoAirWeak(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=1
  CirnoState=6
  anim_type=27
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.05 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 10 then
    sprite=1
    CirnoAttacktype=0
    GenericVariableAtk=0
    CirnoState=1
  end
end
function CirnoAirMedium(dt)
  if GenericVariableAtk==0 then
    sprite=1
    sprite2=8
    GenericVariableAtk=1
  end
  CirnoAttacktype=2
  CirnoState=6
  anim_type=28
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.05 then
    sprite=sprite+1
    if sprite>5 then
      sprite2=sprite2+1
    end
    CirnoAnimationTime = 0
  end
  if sprite>5 then
    SpecialEffects=5
    SpecialEffectX=130
  end
  if sprite>7 and GenericVariable==0 then
    sprite=7
  end
  if sprite2>26 then
    SpecialEffects=0
    GenericVariable=1
  end
  if sprite > 8 then
    sprite=1
    CirnoAttacktype=0
    GenericVariableAtk=0
    sprite2=0
    GenericVariable=0
    SpecialEffects=0
    SpecialEffectX=0
    CirnoState=1
  end
end
function CirnoAirHeavy(dt)
  if GenericVariableAtk==0 then
    sprite=1
    sprite2=18
    GenericVariableAtk=1
  end
  CirnoAttacktype=3
  CirnoState=6
  anim_type=29
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.08 then
    sprite=sprite+1
    if sprite>4 and sprite<12 then
      GenericVariable=GenericVariable+math.pi/4
    end
    if sprite>12 then
      SpecialEffectX=60
      SpecialEffectY=40
      sprite2=sprite2+1
    end
    CirnoAnimationTime = 0
  end
  if sprite>1 then
    SpecialEffects=6
    if GenericVariableAtk==1 then
      SpecialEffectX=30
      SpecialEffectY=-30
      GenericVariableAtk=2
    end
  end
  if sprite>4 and sprite<12 then
    if GenericVariableAtk==2 then
      sprite2=17
      GenericVariableAtk=3
    end
    SpecialEffectX=math.cos(GenericVariable)*30
    SpecialEffectY=math.sin(GenericVariable)*30
  end
  if sprite==12 then
    GenericVariable=0
    sprite2=18
    SpecialEffectX=30
    SpecialEffectY=-10
  end
  if sprite>15 and GenericVariable==1 then
    sprite=15
  end
  if sprite2>23 then
    GenericVariable=2
  end
  if sprite > 16 then
    sprite=1
    CirnoAttacktype=0
    GenericVariableAtk=0
    SpecialEffects=0
    SpecialEffectX=0
    SpecialEffectY=0
    sprite2=0
    GenericVariable=0
    CirnoState=1
  end
end
function CirnoSpecial(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoXSpeed=0
  SpecialEffects=7
  CirnoAttacktype=4
  CirnoState=5
  anim_type=30
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    if GenericVariable==1 then
      sprite2=sprite2+1
    end
    CirnoAnimationTime = 0
  end
  if sprite<5 then
    sprite2=9
    SpecialEffectX=-50
    SpecialEffectY=0
  end
  if sprite>4 and GenericVariable==0 then
    sprite2=10
    GenericVariable=1
    SpecialEffectX=100
    SpecialEffectY=-50
  end
  if sprite>7 and GenericVariable==1 then
    sprite=7
  end
  if sprite2>14 then
    GenericVariable=2
    SpecialEffects=0
  end
  if sprite > 8 then
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
    SpecialEffects=0
    SpecialEffectX=0
    SpecialEffectY=0
    sprite2=0
    GenericVariable=0
  end
end
function CirnoSuper(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoXSpeed=0
  CirnoAttacktype=5
  CirnoState=5
  anim_type=31
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    if sprite>7 then
      if GenericVariable == 0 then
        sprite2=13
        GenericVariable=1
      end
      SpecialEffects=8
      SpecialEffectX=130
      sprite2=sprite2+1
    end
    CirnoAnimationTime = 0
  end
  if sprite>9 and GenericVariable==1 then
    sprite=9
  end
  if sprite2>30 then
    SpecialEffects=0
    GenericVariable=2
  end
  if sprite > 12 then
    sprite=1
    CirnoAttacktype=0
    CirnoState=0
    GenericVariableAtk=0
    sprite2=0
    GenericVariable=0
    SpecialEffects=0
    SpecialEffectX=0
  end
end
function c1:update(dt)
  Charbx=Charbx+CirnoXSpeed*dt
  CirnoYSpeed=CirnoYSpeed+CirnoGravity*500*dt
  Charby=Charby+CirnoYSpeed*dt
  if Charby>StageHeight then
    Charby=StageHeight
    CirnoYSpeed=0
    if CirnoState==1 or CirnoState==6 then
      CirnoLanding(dt)
      CirnoAttacktype=0
      sprite2=0
      SpecialEffects=0
      GenericVariableAtk=0
      SpecialEffects=0
      SpecialEffectX=0
      SpecialEffectY=0
    end
  end
  if CirnoState == 0 then
    if love.keyboard.isDown("z") then
      CirnoNeutralWeak(dt)
    elseif love.keyboard.isDown("x") then
      CirnoNeutralMedium(dt)
    elseif love.keyboard.isDown("c") then
      CirnoNeutralHeavy(dt)
    elseif love.keyboard.isDown("a") then
      CirnoSpecial(dt)
    elseif love.keyboard.isDown("s") then
      CirnoSuper(dt)
    elseif love.keyboard.isDown("right") then
      CirnoWalkForward(dt)
      if love.keyboard.isDown("up") then
        sprite=1
        CirnoJumpForward(dt)
      elseif love.keyboard.isDown("d") then
        CirnoDashForward(dt)
      end
    elseif love.keyboard.isDown("left") then
      CirnoWalkBackward(dt)
      if love.keyboard.isDown("up") then
        sprite=1
        CirnoJumpBackward(dt)
      elseif love.keyboard.isDown("d") then
        CirnoDashBackward(dt)
      end
    elseif love.keyboard.isDown("down") then
      sprite=1
      CirnoCrouch(dt)
    elseif love.keyboard.isDown("up") then
      sprite=1
      CirnoJump(dt)
    else
      CirnoStand(dt)
    end
  elseif CirnoState == 1 then
    if CirnoYSpeed<0 then
      if love.keyboard.isDown("left") then
        CirnoJumpBackward(dt)
      elseif love.keyboard.isDown("right") then
        CirnoJumpForward(dt)
      else CirnoJump(dt)
      end
    end
    if CirnoYSpeed>0 then
      CirnoFalling(dt)
    end
    if love.keyboard.isDown("z") then
      CirnoAirWeak(dt)
    elseif love.keyboard.isDown("x") then
      CirnoAirMedium(dt)
    elseif love.keyboard.isDown("c") then
      CirnoAirHeavy(dt)
    end
  elseif CirnoState == 3 then
    if love.keyboard.isDown("up") then
      CirnoGettingBackUp(dt)
    end
  elseif CirnoState==4 then
    if Guardtype==0 then
      CirnoGuard(dt)
    elseif Guardtype==1 then
      CirnoCrouchGuard(dt)
    end
  elseif CirnoState == 5 then
    if CirnoAttacktype == 1 then
      CirnoNeutralWeak(dt)
    elseif CirnoAttacktype == 2 then
      CirnoNeutralMedium(dt)
    elseif CirnoAttacktype == 3 then
      CirnoNeutralHeavy(dt)
    elseif CirnoAttacktype == 4 then
      CirnoSpecial(dt)
    elseif CirnoAttacktype == 5 then
      CirnoSuper(dt)
    end
  elseif CirnoState == 6 then
    if CirnoAttacktype == 1 then
      CirnoAirWeak(dt)
    elseif CirnoAttacktype == 2 then
      CirnoAirMedium(dt)
    elseif CirnoAttacktype == 3 then
      CirnoAirHeavy(dt)
    end
  elseif CirnoState==8 then
    if CirnoAttacktype == 1 then
      CirnoCrouchingWeak(dt)
    elseif CirnoAttacktype == 2 then
      CirnoCrouchingMedium(dt)
    elseif CirnoAttacktype == 3 then
      CirnoCrouchingHeavy(dt)
    end
  elseif CirnoState == 7 then
    if love.keyboard.isDown("down") then
      CirnoCrouch(dt)
      if love.keyboard.isDown("z") then
        CirnoCrouchingWeak(dt)
      elseif love.keyboard.isDown("x") then
        CirnoCrouchingMedium(dt)
      elseif love.keyboard.isDown("c") then
        CirnoCrouchingHeavy(dt)
      end
    else
      CirnoStandUp(dt)
    end
  elseif CirnoState==9 then
    if GenericVariable==1 then
      CirnoDashForward(dt)
    elseif GenericVariable==2 then
      CirnoDashBackward(dt)
    end
  end
  if EnemyState==5 or EnemyState==6 or EnemyState==8 then
    if love.keyboard.isDown("left") and CirnoState==0 then
      CirnoGuard(dt)
    elseif love.keyboard.isDown("left") and CirnoState==7 then
      CirnoCrouchGuard(dt)
    end
  end


  

end

function c1:draw(--[[charb_x, charb_y, prop]])
  if SpecialEffects==1 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx, Charby, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx-75, Charby-60, hitboxX+150, hitboxY+100)
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==2 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx+SpecialEffectX-15, Charby+SpecialEffectY-15, hitboxX+30, hitboxY+30)
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==3 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 0.6, 0.6, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2+1], Charbx+SpecialEffectX-40, Charby+SpecialEffectY+40, 0, 0.6, 0.6, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY+40, 0, 0.6, 0.6, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX-40, Charby+SpecialEffectY, 0, 0.6, 0.6, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx-25, Charby-30, hitboxX+40, hitboxY+40)
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==4 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, GenericVariable, 0.5, 0.5, (CirnoAnimationFrame[anim_type][sprite2]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()/2))
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx+SpecialEffectX-50, Charby+SpecialEffectY-50, hitboxX+35, hitboxY+25)
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==5 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx+SpecialEffectX-75, Charby+SpecialEffectY-15, hitboxX+35, hitboxY+25)
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==6 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX+33, Charby+SpecialEffectY+33, GenericVariable, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth())/2+30, (CirnoAnimationFrame[anim_type][sprite2]:getHeight())/2+40)
    love.graphics.setColor(255,0,0)
    if sprite>1 and sprite<5 then
      love.graphics.rectangle("line", Charbx+20, Charby-85, hitboxX-40, hitboxY+25)
    end
    if sprite<8 and sprite>4 then
      love.graphics.rectangle("line", Charbx+40, Charby-10, hitboxX, hitboxY+50)
    end
    if sprite>6 and sprite<10 then
      love.graphics.rectangle("line", Charbx+-25, Charby+50, hitboxX+50, hitboxY)
    end
    if  sprite>8 and sprite<12 then
      love.graphics.rectangle("line", Charbx-50, Charby-10, hitboxX, hitboxY+50)
    end
    if  sprite>12 and sprite<16 then
      love.graphics.rectangle("line", Charbx+30, Charby+40, hitboxX+10, hitboxY+20)
    end
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==7 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    if sprite2>9 then
    love.graphics.rectangle("line", Charbx+SpecialEffectX-20, Charby+SpecialEffectY-10, hitboxX+75, hitboxY+70)
    end
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==8 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][32], 400, 300, 0, 3.2, 3.2, (CirnoAnimationFrame[anim_type][sprite2]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight())/2)
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", 0, 0, 800, 600)
    love.graphics.setColor(255,255,255)
  
  elseif SpecialEffects==9 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
  end
  
  love.graphics.draw(CirnoAnimationFrame[anim_type][sprite], Charbx, Charby--[[, 0, prop]])
  love.graphics.rectangle("line", Charbx, Charby, hitboxX, hitboxY)
  love.graphics.setColor(0,0,255)
  love.graphics.rectangle("line", Charbx, Charby+5, hitboxX-10, hitboxY-10)
  love.graphics.setColor(255,255,255)
end

return c1