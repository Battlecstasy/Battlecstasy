local cirno = require("c1")

function love.load()
  cirno:new()
end

function love.update(dt)
  cirno:update(dt)
end

function love.draw()
  cirno:draw()
end