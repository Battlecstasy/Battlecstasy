local Player = {}
local player, p_matrizhelp
-- p_matrizhelp ajuda a colocar valores dentro de player sem necessitar de condicionais
function Player:new(p1, p2, pos_chao)
  player = {}
  p_matrizhelp = {p1, p2, -1, 1}
  
  for i=1,2 do
    player[i] = {persNum = p_matrizhelp[i], pers, persImg, lifebar = 90, superbar = 100, side = p_matrizhelp[i+2]}
    player[i].pers = require("characters/char/c1")--[[..player[i].persNum.."/char"..player[i].persNum) --Retirar "1/char1" da parte anterior]]
    player[i].persImg = love.graphics.newImage("characters/char"..player[i].persNum..".png")
    player[i].pers:new(pos_chao)
  end
end

function Player:update(dt)
  player[1].pers:update(dt)
  --player[2].pers:update(dt)
end

--[[
function Player:keypressed()
  for i=1,2 do
    player[i].pers:keypressed()
  end]]

function Player:draw(prop, extraX, extraY)
    player[1].pers:draw()
    --player[2].pers:draw()
  for i=1,2 do
    love.graphics.draw(player[i].persImg, extraX+(50+(i-1)*650)*prop, extraY+60*prop, 0 , prop)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("fill", extraX+(400*(i-1)+50)*prop, extraY+100*prop, 300*prop, 25*prop, 10)
    love.graphics.setColor(0,255,0)
    love.graphics.rectangle("fill", extraX+(400*(i-1)+3*(100-player[i].lifebar)*(2-i)+50)*prop, extraY+100*prop, 3*player[i].lifebar*prop, 25*prop, 10)
    love.graphics.setColor(0,0,255)
    for j=0,2 do
      love.graphics.rectangle("line", extraX+(600*(i-1)+50)*prop, extraY+150*prop, 100*prop, 12*prop, 10)
    end
    love.graphics.setColor(255,255,255)
    love.graphics.rectangle("fill", extraX+(400*(i-1)+(100-player[i].superbar)*(2-i)+50)*prop, extraY+150*prop, player[i].superbar*prop, 12*prop, 10)
    love.graphics.setColor(255,255,255)
  end
    --BARRA DE VIDA: O LADO DIREITO VAI AUMENTAR O x E DIMINUIR O WIDTH. O LADO ESQUERDO VAI DIMINUIR O WIDTH APENAS
  
end

return Player