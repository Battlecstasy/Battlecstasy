--*Lembrar de conectar a arena_base a game. Além disso, está faltando um player.lua. Será possível chamar arenaNum no Arena_Base:new() toda vez que a tela de jogo (game) for iniciada?

local Arena_Base = {}
local bg_images = {}
local arenaMaxy
--local bg_sounds = {}
--local start = true

function Arena_Base:new(arenaNum)
  for i = 1,18 do
    bg_images[i] = love.graphics.newImage("arenas/"..i)
    --bg_sounds[i] = love.audio.newSource("background/sound"..i, "stream")
  end
  
end

function Arena_Base:draw(extraX, extraY, prop, arenaNum)
  
  love.graphics.draw(bg_images[arenaNum], extraX, extraY, 0, prop)
  --if start then
  --  start = false
  --  bg_sounds[arenaNum]:play()
  --  bg_sounds[arenaNum]:setLooping(true)
  --end
end

return Arena_Base