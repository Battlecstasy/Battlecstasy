local Game = {}
local bump, world, hitbox, item, pers1_posX, pers1_posY, pers2_posX, pers2_posY

function Game:new()
  pers1_posX = 0
  pers1_posY = 300
  pers2_posX = 700
  pers2_posY = 300
  bump = require("bumplib/bump")
  item = {name = "A", name = "B"}
  world = {bump.newWorld(), bump.newWorld()}
  hitbox = {world[1]:add(item[1], pers1_posX, pers1_posY, 64, 64), world[1]:add(item[2], pers2_posX, pers2_posY, 64, 64)}
end

function Game:update(dt)
  if love.keyboard.isDown("d") then
    pers1_posX = pers1_posX+100*dt
  end
  if love.keyboard.isDown("left") then
    pers1_posX = pers1_posX-100*dt
  end
  world:update()
  world:check(item[1])
end

function Game:draw()
  love.graphics.rectangle("fill", pers1_posX, pers1_posY, 64, 64)
  love.graphics.rectangle("fill", pers2_posX, pers2_posY, 64, 64)
end
