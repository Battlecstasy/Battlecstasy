Menu = {}
local enemy
local images = {love.graphics.newImage("background.png"), love.graphics.newImage("logo.png"), love.graphics.newImage("jogar.png"), love.graphics.newImage("opcao.png"), love.graphics.newImage("creditos.png")}

function Menu:new(windX, windY)
  
  menu = {botao = 0}
  setmetatable(menu, {__index = Menu})
  enemy = love.audio.newSource("enemy.mp3")
  love.audio.play(enemy)
  return menu
end

function Menu:keyreleased(key, tela)
  if key == "down" then
    if menu.botao ~= 3 then
      menu.botao = menu.botao + 1
    else
      menu.botao = 1
    end
  elseif key == "up" then
    if menu.botao > 1 then
      menu.botao = menu.botao - 1
    else
      menu.botao = 3
    end
  elseif key == "return" and menu.botao ~= 0 then
    tela = menu.botao
    love.audio.pause(enemy)
    love.audio.rewind(enemy)
  end
end

function Menu:update(mouseX, mouseX2, mouseY, mouseY2, prop)
  --Parte para o mouse
  if (mouseX ~= mouseX2  and mouseY ~= mouseY2) then
    if (mouseX > 250*prop and mouseX < 500*prop) then
      if (mouseY > 250*prop and mouseY < 300*prop) then
        menu.botao = 1
      elseif (mouseY > 350*prop and mouseY < 400*prop) then
        menu.botao = 2
      elseif (mouseY > 450*prop and mouseY < 500*prop) then
        menu.botao = 3
      else
        menu.botao = 0
      end
    else
      menu.botao = 0
    end
  end  
end

function Menu:draw(prop)
  love.graphics.draw(images[1], 0, 0, 0, prop)
  love.graphics.draw(images[2], 100*prop, 50*prop, 0, prop)
  
  if menu.botao ~= 0 then
    love.graphics.rectangle("line", 225*prop, (125+100*menu.botao)*prop, 300*prop, 100*prop, 0, prop)
  end
  
  for i = 3,5 do
    love.graphics.draw(images[i], 250*prop, (100*i-50)*prop, 0, prop)
    love.graphics.draw(images[i], 500*prop, (100*i-50)*prop, 0, prop) --retirar depois
  end
  
end