Menu = {}
local mouseX = 0
local mouseY = 0

function Menu:new()
  local menu = {logo = love.graphics.newImage("logo.png"),
    jogarBox, jogar = love.graphics.newImage("jogar.png"),
    opcaoBox, opcao = love.graphics.newImage("opcao.png"),
    creditosBox, creditos = love.graphics.newImage("creditos.png")
    marcador = {--[[criar um vetor de cores para um selecionador]]},
    botao = 0}
  setmetatable(menu, {__index = Menu}
  return menu
end

function Menu:update()
  mouseX = love.mouse.getX()
  mouseY = love.mouse.getY()
  
  if (mouseX > 300 and mouseX < 500) then
    if (mouseY > 150 and mouseY < 200) then
      menu.botao = 1
    elseif (mouseY > 250 and mouseY < 300) then
      menu.botao = 2
    elseif (mouseY > 150 and mouseY < 200) then
      menu.botao = 3
    else
      menu.botao = 0
    end
  else
    menu.botao = 0
  end
  

end

function Menu:draw()
  love.graphics.draw(menu.logo,
end

