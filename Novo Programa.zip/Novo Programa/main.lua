require("menu")
require("option")
require("credits")
require("sel_pers")
require("sel_fase")
require("game")

function love.load()
end

function love.update()
end

function love.draw()
end
