require("menu")
--require("option")
local tela, windX, windY, mouseX, mouseX2, mouseY, mouseY2, proporcao, count

--[[require("credits")
require("sel_pers")
require("sel_fase")
require("game")]]
local menu

function proportionalResize()
  windX = love.graphics.getWidth()
  windY = love.graphics.getHeight()
  
  if (windX/windY > 4/3) then
    windX = windY*(4/3)
  elseif (windX/windY < 4/3) then
    windY = windX*(3/4)
  end
  proporcao = windX/800
end


function love.load()
  tela = 0
  love.window.setMode(800,600,{resizable=true, minwidth = 800, minheight = 600});
  proportionalResize()  
  menu = Menu:new()
  count = 0
end

function love.keyreleased(key)
  menu:keyreleased(key, tela)
  
  
  if key == "f" then        -- Problemas de novo com getWidth e getHeight e Fullscreen.
    if count == 0 then
      love.window.setFullscreen(true, "desktop")
      count = 1
    else
      love.window.setFullscreen(false)
      count = 0
    end
  end
  
  if key == "escape" then
    love.event.quit()
  end
end

function love.update(dt)
  proportionalResize()
  mouseX = love.mouse.getX()
  mouseY = love.mouse.getY()
  menu:update(mouseX, mouseX2, mouseY, mouseY2, proporcao)
  mouseX2 = mouseX
  mouseY2 = mouseY
end

function love.draw()
  menu:draw(proporcao)
end
