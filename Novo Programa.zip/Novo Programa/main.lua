require("menu")
--require("option")
local tela, windX, windX2, windY, windY2, mouseX, mouseX2, mouseY, mouseY2, proporcao, count

--[[require("credits")
require("sel_pers")
require("sel_fase")
require("game")]]
local menu

function proportionalResize()
  windX = love.graphics.getWidth()
  windY = love.graphics.getHeight()
  windX2 = windX
  windY2 = windY
  
  if (windX/windY > 4/3) then
    windX = windY*(4/3)
  elseif (windX/windY < 4/3) then
    windY = windX*(3/4)
  end
  windX2 = (windX2 - windX)/2
  windY2 = (windY2 - windY)/2
  proporcao = windX/800
end


function love.load()
  tela = 0
  love.window.setMode(800,600,{resizable=true, minwidth = 800, minheight = 600});
  proportionalResize()  
  menu = Menu:new()
  count = 0
end

function love.keyreleased(key)
  if tela == 0 then
    menu:keyreleased(key, tela)
  end
  
  if key == "f12" then        -- Problemas de novo com getWidth e getHeight e Fullscreen.
    if count == 0 then
      love.window.setFullscreen(true, "desktop")
      count = 1
    else
      love.window.setFullscreen(false)
      count = 0
    end
  end
  
  if key == "escape" then
    love.event.quit()
  end
end

function love.mousepressed(x, y, button)
  if tela == 0 then
    menu:mousepressed(button, tela, mouseX, mouseY, proporcao, windX2, windY2)
  end
end

function love.update(dt)
  proportionalResize()
  mouseX = love.mouse.getX()
  mouseY = love.mouse.getY()
  if tela == 0 then
    menu:update(dt, mouseX, mouseX2, mouseY, mouseY2, proporcao, windX2, windY2)
  end
  mouseX2 = mouseX
  mouseY2 = mouseY
end

function love.draw()
  if tela == 0 then
    menu:draw(proporcao, windX2, windY2)
  end
end
