local Player = {}
local player, p_matrizhelp, playerName
charName = {"Chun-Li","Cirno","Dio","Morgiana","Ky","Bowser","Popeye","Archer"}
-- p_matrizhelp ajuda a colocar valores dentro de player sem necessitar de condicionais
function Player:new(p1, p2, pos_chao)
  p_font = love.graphics.newFont(18)
  player = {}
  p_matrizhelp = {p1, p2, -1, 1}
  
  for i=1,2 do
    player[i] = {persNum = p_matrizhelp[i], pers, persImg, lifebar = 100, superbar = 0, side = p_matrizhelp[i+2]}
    player[i].pers = require("characters/char/c1")--[[..player[i].persNum.."/char"..player[i].persNum) --Retirar "1/char1" da parte anterior]]
    player[i].persImg = love.graphics.newImage("characters/char"..player[i].persNum..".png")
    player[i].pers:new(pos_chao)
  end
end

function Player:update(dt)
    player[1].pers:update(dt)
  --player[2].pers:update(dt)
  return player[1].lifebar, player[2].lifebar
end

--[[
function Player:keypressed()
  for i=1,2 do
    player[i].pers:keypressed()
  end]]

function Player:draw(prop, extraX, extraY)
    -- PERSONAGENS NA TELA --
    player[1].pers:draw(prop, extraX, extraY)
    --player[2].pers:draw()
  
  for i=1,2 do
    -- RETRATO DO PERSONAGEM --
    love.graphics.draw(player[i].persImg, extraX+(50+(i-1)*650)*prop, extraY+60*prop, 0 , prop)
    -- NOME DO PERSONAGEM --
    love.graphics.print(charName[player[i].persNum], extraX+(105+(i-1)*(575-p_font:getWidth(charName[player[i].persNum])))*prop, extraY+72*prop, 0 , prop) 
    -- BARRA DE VIDA --
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("fill", extraX+(400*(i-1)+50)*prop, extraY+100*prop, 300*prop, 25*prop, 10)
    love.graphics.setColor(0,255,0)
    love.graphics.rectangle("fill", extraX+(400*(i-1)+3*(100-player[i].lifebar)*(2-i)+50)*prop, extraY+100*prop, 3*player[i].lifebar*prop, 25*prop, 10)
    love.graphics.setColor(0,0,255)
    -- BARRA DE SUPER --
    for j=0,2 do
      love.graphics.rectangle("line", extraX+(500*(i-1)+50-j)*prop, extraY+(150-j)*prop, (200+2*j)*prop, (12+2*j)*prop, 5)
    end
    if player[i].superbar ~= 0 then
      love.graphics.setColor(150,150,255)
      love.graphics.rectangle("fill", extraX+(500*(i-1)+2*(100-player[i].superbar)*(i-1)+50)*prop, extraY+150*prop, 2*player[i].superbar*prop, 12*prop, 5)
    end
    love.graphics.setColor(255,255,255)
  end
    --BARRA DE VIDA: O LADO DIREITO VAI AUMENTAR O x E DIMINUIR O WIDTH. O LADO ESQUERDO VAI DIMINUIR O WIDTH APENAS
    --BARRA DE SUPER: OPOSTO DA BARRA DE VIDA
  
end

return Player