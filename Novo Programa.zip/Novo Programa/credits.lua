Credits = {}
local nomes

function Credits:new()
  credits = {}
  setmetatable(credits, {__index, Credits}
  nomes = {"Alexandre Heine", "Breno Alberigi", "Gabriel Rocha", "Henrique Peres", "Marcelo Drummond", "Isabela ?"}
  return credits
end

function Credits:update()

end

function Credits:draw(prop, fonte1, fonte2)
  love.graphics.setFont(fonte1)
  love.graphics.draw("Agradecimentos", 300*prop, 25*prop, 5*prop)
  love.graphics.setFont(fonte2)
  for i = 1,6 do
    love.graphics.draw(nomes[i], 350*prop, (150+50*i)*prop, prop)
  end
  love.graphics.rectangle("fill", 350*prop, 500*prop, 100*prop, 50*prop)
  love.graphics.draw("VOLTAR", 375*prop, 510*prop, prop)
end