local anim_time, posX, posY

function love.update(dt)
  if love.keyboard.isDown("right") then
    posX = posX + (100 * dt) -- movimenta o personagem
    anim_time = anim_time + dt
    if Chun_li_anim_frame > 15 then
      Chun_li_anim_frame = 1
    end
  end
  if love.keyboard.isDown("left") then
    Chun_li_pos_x = Chun_li_pos_x + (-100 * dt) -- movimenta o personagem
    Chun_li_anim_time = Chun_li_anim_time + dt
    if Chun_li_anim_frame > 31 or Chun_li_anim_frame < 17 then
      Chun_li_anim_frame = 17
    end
  end
  
  
  if Chun_li_anim_time > 0.06 then -- quando acumular mais de 0.1
    Chun_li_anim_frame = Chun_li_anim_frame + 1 -- avança para proximo frame
    Chun_li_anim_time = 0
  end
end

function love.draw() -- desenha o personagem usando o indice da animação
  love.graphics.draw(Chun_li_walk[Chun_li_anim_frame], Chun_li_pos_x, Chun_li_pos_y)
end