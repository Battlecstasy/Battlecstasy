local CharBase = {}
local char

function CharBase:new(charNum)
  if charNum == 1 then
    char = "Cirno"
  end
  require(char)
  
end

function CharBase:update()
  require

return CharBase