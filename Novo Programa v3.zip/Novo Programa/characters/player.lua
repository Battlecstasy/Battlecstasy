local Player = {}
local jogador = {}

function Player:new()
  cirno = require("Cirno")
  char_select = require("char_selection/char_selection")
  charInterf = cirno:Interf()
  charNum = char_select:characterNumber()
  for i=1,2 do
    jogador[i] = {charNum, life = 0 , superBar = 0, charInterf}
  end
end

function Player:update()
end

return Player