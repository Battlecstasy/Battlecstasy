local Arena_Selection = {}
local as_image, as_arena, as_voltar, as_botao, as_player

function Arena_Selection:new(fonte1, fonte3)
  as = "arena_selection/"
  as_image = love.graphics.newImage(as.."background.png")
  as_arena = love.graphics.newImage(as.."arena.png")

  as_player = {}
  for i = 1,2 do
    --for j = 1,3 do
    as_player[i] = love.graphics.newImage(as.."player"..i.."1.png")
    --end
  end

  as_voltar = {}
  for i=1,2 do
    as_voltar[i] = love.graphics.newImage(as.."voltar"..i..".png")
  end

  as_botao = {1,1,0,0,false}

  as_font = {love.graphics.setNewFont(fonte3, 15), love.graphics.setNewFont(fonte1, 40), love.graphics.setNewFont(fonte1, 25), love.graphics.setNewFont(fonte1, 32)}
end

function Arena_Selection:draw(prop, extraX, extraY)
  -- BACKGROUND E IMAGEM DAS ARENAS --
  love.graphics.draw(as_image, extraX, extraY, 0, prop)
  love.graphics.draw(as_arena, extraX, extraY+133*prop, 0, 1.2*prop)

  -- RETANGULO E TITULO DA TELA --
  love.graphics.setColor(0,0,0)
  love.graphics.rectangle("fill", extraX, extraY, 800*prop, 44*prop)
  love.graphics.setColor(255,255,255)
  love.graphics.setFont(as_font[2])
  love.graphics.print("ESCOLHA DE ARENA", extraX+50*prop, extraY+5*prop, 0, prop)

  -- -- -- BOTAO VOLTAR -- -- --
  if not as_botao[5] then
    love.graphics.draw(as_voltar[1], extraX, extraY+44*prop, 0, prop)
  else
    love.graphics.draw(as_voltar[2], extraX, extraY+44*prop, 0, prop)
  end
  love.graphics.setFont(as_font[3])
  love.graphics.print("VOLTAR", extraX+50*prop, extraY+93*prop, 0, prop)

  -- INTERFACE DOS JOGADORES --
  love.graphics.setFont(as_font[1])
  for i=1,2 do
    love.graphics.draw(as_player[i], extraX+500*prop, extraY+(133+(as_arena:getHeight()*(0.48)*(i-1)))*prop, 0, prop)
    love.graphics.print("JOGADOR "..i, extraX+501*prop, extraY+(142+(as_arena:getHeight()*(0.48)*(i-1)))*prop, 0, prop)
  end

end

return Arena_Selection