local pkX, pkY, speed, ind, count, pkImages, rotation, translationX, translationY, xAxis, yAxis, raioVariable
local background, thunder, k, shock -- tirar do pikachu.lua (atual main.lua)
-- imagens
require("raio2")

-- local pokemon

function love.load()
  pkImages = {love.graphics.newImage("Pikachu/pikachu14.png"), love.graphics.newImage("Pikachu/pikachu15.png"), love.graphics.newImage("Pikachu/pikachu16.png"), love.graphics.newImage("Pikachu/pikachu17.png"), love.graphics.newImage("Pikachu/pikachu18.png"), love.graphics.newImage("Pikachu/pikachu19.png"), love.graphics.newImage("Pikachu/pikachu20.png"), love.graphics.newImage("Pikachu/pikachu21.png"), love.graphics.newImage("Pikachu/pikachu22.png"), love.graphics.newImage("Pikachu/pikachu23.png"), love.graphics.newImage("Pikachu/pikachu24.png"), love.graphics.newImage("Pikachu/pikachu25.png"), love.graphics.newImage("Pikachu/pikachu26.png"), love.graphics.newImage("Pikachu/pikachu27.png"), love.graphics.newImage("Pikachu/pikachu28.png"), love.graphics.newImage("Pikachu/pikachu52.png"), love.graphics.newImage("Pikachu/pikachu53.png"), love.graphics.newImage("Pikachu/pikachu54.png"), love.graphics.newImage("Pikachu/pikachu55.png"), love.graphics.newImage("Pikachu/pikachu56.png"), love.graphics.newImage("Pikachu/pikachu57.png")}
  background = love.graphics.newImage("Background/background.png")
  -- imagens do Pikachu e background
  pkX = 25 -- posição do Pikachu em x
  pkY = 400 -- posição do Pikachu em y
  speed = 0 -- movimentação do Pikachu
  ind = 1 -- indice para o vetor de imagens: pkImages
  count = 0 -- contador de tempo para a animação
  rotation = 0 -- rotação do Pikachu
  translationX = 1 -- translação do Pikachu em x
  translationY = 1 -- translação do Pikachu em y
  k = 0
  thunder = Raio:new() -- ataque especial da classe raio
  shock = false
  
end

function love.update(dt)
  k = dt
  if (love.keyboard.isDown("left") and pkX >= 25) then 
    -- Pressionar "left" ele translada a imagem para que dê a ideia de andar para a esquerda e tem uma velocidade negativa no janela.
    speed = -100*dt
    translationX = -1
    
  elseif (love.keyboard.isDown("right") and pkX < 775) then 
    -- Pressionar "right" ele translada a imagem para que dê a ideia de andar para a direita e tem uma velocidade positiva na janela.
    speed = 100*dt
    translationX = 1
  else  
    -- Caso nenhuma das duas teclas acima estejam pressionadas, ele fica parado, por isso velocidade nula.
    speed = 0
  end
  
  if (count == 7) then -- Toda vez que o contador for 5, as condições abaixo são executadas (ajeitar, por causa da animação de estar parado estar rápida demais).
    if (speed == 0 and ind < 15) or (speed ~= 0 and ind > 15 and  ind < 21) then
      ind = ind + 1
    elseif (speed == 0 and ind >= 15) then
      ind = 1
    elseif (speed ~= 0 and ind >= 1 and ind < 16) then
      ind = 16
    elseif (speed ~= 0 and ind >= 21) then
      ind = 17
    end
    count = 0
  end
  if (love.keyboard.isDown("space")) then
      shock = true
  end    
  if (speed==0 and shock) then
    --raioVariable = thunder:variable()
    --while(raioVariable<6) do
      thunder:update(k, pkX, translationX)
      if (thunder.count > 45) then
        shock = false
        thunder.count = 0
        thunder.posY = 0
        thunder.variavel = 1
      end
  end
  count = count+1
  pkX = pkX + speed
  
end

function love.keyreleased(key)
  if key == "escape" then
    love.event.quit()
  end
end

function love.draw()
  xAxis = pkImages[ind]:getWidth()/2 -- Eixo x de translação do Pikachu (esse eixo está embaçando a imagem do Pikachu, mas não sei o motivo)
  yAxis = pkImages[ind]:getHeight()/2 -- Eixo y de translação do Pikachu
  love.graphics.draw(background, 0, 0) -- Desenho do background (transferir para a classe background.lua depois).
  love.graphics.draw(pkImages[ind], pkX, pkY, rotation, translationX, translationY, xAxis, yAxis) -- Desenho do Pikachu
  if (shock == true) then
    thunder:draw(xAxis)
  end
end