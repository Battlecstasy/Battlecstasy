Menu = {}
local enemy, count
local images = {love.graphics.newImage("background.png"), love.graphics.newImage("logo.png"), love.graphics.newImage("jogar.png"), love.graphics.newImage("opcao.png"), love.graphics.newImage("creditos.png")}

function Menu:new(windX, windY)
  
  menu = {botao = 0}
  setmetatable(menu, {__index = Menu})
  enemy = love.audio.newSource("enemy.mp3")
  count = 0
  love.audio.play(enemy)
  return menu
end

function Menu:keyreleased(key, tela)
  if key == "down" then
    if menu.botao ~= 3 then
      menu.botao = menu.botao + 1
    else
      menu.botao = 1
    end
  elseif key == "up" then
    if menu.botao > 1 then
      menu.botao = menu.botao - 1
    else
      menu.botao = 3
    end
  elseif key == "return" and menu.botao ~= 0 then
    tela = menu.botao
    love.audio.pause(enemy)
    love.audio.rewind(enemy)
  end
end

function Menu:mousepressed(button, tela, mouseX, mouseY, prop, extraX, extraY)
  if botao ~= 0 and button == 1 and (mouseX > extraX+250*prop and mouseX < extraX+500*prop) and ((mouseY > extraY+250*prop and mouseY < extraY+300*prop) or (mouseY > extraY+350*prop and mouseY < extraY+400*prop) or (mouseY > extraY+450*prop and mouseY < extraY+500*prop)) then
    tela = menu.botao
    love.audio.pause(enemy)
    love.audio.rewind(enemy)
  end
end


function Menu:update(dt, mouseX, mouseX2, mouseY, mouseY2, prop, extraX, extraY)
  --Parte para o mouse
  if (mouseX ~= mouseX2  and mouseY ~= mouseY2) then
    if (mouseX > extraX+250*prop and mouseX < extraX+500*prop) then
      if (mouseY > extraY+250*prop and mouseY < extraY+300*prop) then
        menu.botao = 1
      elseif (mouseY > extraY+350*prop and mouseY < extraY+400*prop) then
        menu.botao = 2
      elseif (mouseY > extraY+450*prop and mouseY < extraY+500*prop) then
        menu.botao = 3
      else
        menu.botao = 0
      end
    else
      menu.botao = 0
    end
  end  
  
  count = count+dt
  if count > 165 then
    love.audio.play(enemy)
  end
  
end

function Menu:draw(prop, extraX, extraY)
  love.graphics.draw(images[1], extraX, extraY, 0, prop)
  love.graphics.draw(images[2], extraX+100*prop, extraY+50*prop, 0, prop)
  
  if menu.botao ~= 0 then
    love.graphics.rectangle("line", extraX+225*prop, extraY+(125+100*menu.botao)*prop, 300*prop, 100*prop, 0, prop)
  end
  
  for i = 3,5 do
    love.graphics.draw(images[i], extraX+250*prop, extraY+(100*i-50)*prop, 0, prop)
    love.graphics.draw(images[i], extraX+500*prop, extraY+(100*i-50)*prop, 0, prop) --retirar depois
  end
  
end