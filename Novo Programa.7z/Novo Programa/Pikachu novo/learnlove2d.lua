local ind, count
local pokemon

function love.load()
  pokemon = love.graphics.newImage("Pikachu/pikachu14.png")
  ind = 1
  count = 0
end

function love.update(dt)
  if count >= 75 then
    ind = ind*100*dt
    
  end
  count = count+1
end

function love.draw()
  love.graphics.draw(pokemon, ind, 100)
end