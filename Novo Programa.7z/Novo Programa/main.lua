local tela, windX, windX2, windY, windY2, mouseX, mouseX2, mouseY, mouseY2, proporcao, count, fonte1, fonte2, enemy
-- tela -> número da tela desenhada; windX2 e windY2 -> centralizadores de tela; mouseX e mouseY -> posições atuais do mouse
-- mouseX2 e mouseY2 -> posições anteriores do mouse; proporcao -> proporção da tela windX/windY; count -> contador para o modo de fullscreen
-- fonte1 e fonte2 -> fontes de texto
-- count2 -> para a músicas

--[[
require("sel_pers")
require("sel_fase")
require("game")]]
local menu, option, credits


function proportionalResize()
  windX = love.graphics.getWidth()
  windY = love.graphics.getHeight()
  windX2 = windX
  windY2 = windY
  
  if (windX/windY > 4/3) then
    windX = windY*(4/3)
  elseif (windX/windY < 4/3) then
    windY = windX*(3/4)
  end
  windX2 = (windX2 - windX)/2
  windY2 = (windY2 - windY)/2
  proporcao = windX/800
end


function love.load()
  credits = require("credits/credits")
  menu = require("menu/menu")
  option = require("option/option")
  --MUSICA
  enemy = love.audio.newSource("menu/enemy.mp3", "stream")
  love.audio.play(enemy)
  enemy:setLooping(true)
  count2 = 0
  --TELA
  tela = 0
  love.window.setMode(800,600,{resizable=true, minwidth = 800, minheight = 600});
  love.window.setTitle("Battlecstasy")
  proportionalResize()
  --TEXTO (Dica da noite: crie uma variavel para cada fonte que recebe um valor em função da tela.)
  fonte1 = "feast.ttf"
  fonte2 = "bumrush.ttf"
  --CHAMADA DO NEW DAS OUTRAS CLASSES
  menu:new(fonte1, fonte2)
  option:new(fonte1, fonte2)
  credits:new(fonte1, fonte2)
  count = 0
end

function love.keyreleased(key)
  
  if tela == 0 then
    tela = menu:keyreleased(key)
  elseif tela == 3 then
    tela = credits:keyreleased(key)
  end
  
  if key == "f12" then
    if count == 0 then
      love.window.setFullscreen(true, "desktop")
      count = 1
    else
      love.window.setFullscreen(false)
      count = 0
    end
  end
  
  if key == "escape" then
    love.event.quit()
  end
end

function love.mousereleased(x, y, button)
  if tela == 0 then
    tela = menu:mousereleased(button, mouseX, mouseY, proporcao, windX2, windY2)
  elseif tela == 3 then
    tela = credits:mousereleased(button, mouseX, mouseY, proporcao, windX2, windY2)
  end
end

function love.update(dt)  
  if tela==1 or tela>4 then
    enemy:pause()
    enemy:rewind()
  end
  --GRAFICOS E TEXTOS
  proportionalResize()
  mouseX = love.mouse.getX()
  mouseY = love.mouse.getY()
  if tela == 0 then
    menu:update(dt, mouseX, mouseX2, mouseY, mouseY2, proporcao, windX2, windY2)
  elseif tela == 3 then
    credits:update(dt, mouseX, mouseX2, mouseY, mouseY2, proporcao, windX2, windY2)
  end
  mouseX2 = mouseX
  mouseY2 = mouseY
end

function love.draw()
  if tela == 0 then
    menu:draw(proporcao, windX2, windY2)
  elseif tela == 2 then
    option:draw(proporcao, windX2, windY2, fonte1, fonte2)
  elseif tela == 3 then
    credits:draw(proporcao, windX2, windY2, fonte1, fonte2)
  end
  --io.write(tela)
end
