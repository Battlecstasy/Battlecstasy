local Option = {}
local botao, var, image, font1, font2, font3

function Option:new(fonte1, fonte2)
  botao = 0
  var = 0
  image = love.graphics.newImage("option/background.png")
  font = {love.graphics.setNewFont(fonte1, 70), love.graphics.setNewFont(fonte1, 40), love.graphics.setNewFont(fonte2, 15)}
end

function Option:update()
  
end

function Option:draw(prop, extraX, extraY)
  love.graphics.draw(image, extraX, extraY, 0 , prop) -- background
  
  love.graphics.setColor(0,0,0)
  love.graphics.rectangle("fill", extraX+120*prop, extraY+295*prop, 100*prop, 50*prop)-- MODO RET
  love.graphics.rectangle("fill", extraX+120*prop, extraY+295*prop, 100*prop, 50*prop)-- VOLUME RET
  
  love.graphics.setColor(255,255,255) -- Retangulos do +, -, MUTE.
  --VOLUME RETANGULO
  for i=1,3 do
    if i == 3 then
      var = 75
    else 
      var = 25
    end
    love.graphics.rectangle("fill", extraX+(50*i+300)*prop, extraY+210*prop, var*prop, 25*prop)
  end
  --MODO RETANGULO
  love.graphics.rectangle("fill", extraX+285*prop, extraY+313*prop, 125*prop, 25*prop)--TELA CHEIA RET
  love.graphics.rectangle("fill", extraX+440*prop, extraY+313*prop, 85*prop, 25*prop)--JANELA RET
  
  -- -- -- -- -- -- -- -- -- -- TEXTO -- -- -- -- -- -- -- -- -- --
  love.graphics.setFont(font[1])
  love.graphics.print("Ajustes", extraX+300*prop, extraY+50*prop, 0, prop) -- AJUSTES
  love.graphics.setFont(font[2])
  love.graphics.print("MODO", extraX+125*prop, extraY+300*prop, 0, prop) --MODO
  love.graphics.print("VOLUME", extraX+125*prop, extraY+200*prop, 0, prop) -- VOLUME
  love.graphics.print(love.audio.getVolume()*100, extraX+285*prop, extraY+213*prop, 0, prop)
  
  love.graphics.setColor(0,0,0) 
  love.graphics.setFont(font[3])
  --VOLUME
  love.graphics.print("+", extraX+355*prop, extraY+210*prop, 0, prop)-- MAIS
  love.graphics.print("-", extraX+406*prop, extraY+200.5*prop, 0, prop)-- MENOS
  love.graphics.print("MUDO", extraX+460*prop, extraY+212*prop, 0, prop) --MUDO
  --MODO
  love.graphics.print("TELA CHEIA", extraX+293*prop, extraY+315*prop, 0, prop) --TELA CHEIA
  love.graphics.print("JANELA", extraX+448*prop, extraY+315*prop, 0, prop) --JANELA
  --VOLTAR
  love.graphics.setFont(font[2])
  love.graphics.print("VOLTAR", extraX+350*prop, extraY+400*prop, 0, prop) --VOLTAR
  love.graphics.setColor(255,255,255)
 end

return Option