local Menu = {}
local enemy, count, botao
-- enemy -> música de fundo; count -> contador de tempo para reiniciar a música
-- botao -> verificador de qual botao está para ser ativado pelo usuário
local images = {love.graphics.newImage("menu/background.png"), love.graphics.newImage("menu/logo.png"), love.graphics.newImage("menu/jogar.png"), love.graphics.newImage("menu/opcao.png"), love.graphics.newImage("menu/creditos.png")}

function Menu:new(fonte1, fonte2)
  botao = 0
end

function Menu:keyreleased(key)
  if key == "down" then
    if botao ~= 3 then
      botao = botao + 1
    else
      botao = 1
    end
    return 0
  elseif key == "up" then
    if botao > 1 then
      botao = botao - 1
    else
      botao = 3
    end
    return 0
  elseif key == "return" and botao ~= 0 then
    return botao
  else
    return 0
  end
end

function Menu:mousereleased(button, mouseX, mouseY, prop, extraX, extraY)
  if botao ~= 0 and button == 1 then
    if (mouseX > extraX+250*prop and mouseX < extraX+500*prop) then
      if (mouseY > extraY+250*prop and mouseY < extraY+300*prop) then
        botao = 1
      elseif (mouseY > extraY+350*prop and mouseY < extraY+400*prop) then
        botao = 2
      elseif(mouseY > extraY+450*prop and mouseY < extraY+500*prop) then
        botao = 3  
      else
        botao = 0
      end
      return botao
    else
      return 0
    end
  else
    return 0
  end
end


function Menu:update(dt, mouseX, mouseX2, mouseY, mouseY2, prop, extraX, extraY)
  --Parte para o mouse
  if (mouseX ~= mouseX2  and mouseY ~= mouseY2) then
    if (mouseX > extraX+250*prop and mouseX < extraX+500*prop) then
      if (mouseY > extraY+250*prop and mouseY < extraY+300*prop) then
        botao = 1
      elseif (mouseY > extraY+350*prop and mouseY < extraY+400*prop) then
        botao = 2
      elseif (mouseY > extraY+450*prop and mouseY < extraY+500*prop) then
        botao = 3
      else
        botao = 0
      end
    else
      botao = 0
    end
  end

  
  
end

function Menu:draw(prop, extraX, extraY)
  love.graphics.draw(images[1], extraX, extraY, 0, prop)
  love.graphics.draw(images[2], extraX+100*prop, extraY+50*prop, 0, prop)
  
  if botao ~= 0 then
    love.graphics.rectangle("line", extraX+225*prop, extraY+(125+100*botao)*prop, 300*prop, 100*prop, 0, prop)
  end
  
  for i = 3,5 do
    love.graphics.draw(images[i], extraX+250*prop, extraY+(100*i-50)*prop, 0, prop)
    love.graphics.draw(images[i], extraX+500*prop, extraY+(100*i-50)*prop, 0, prop) --retirar depois
  end
  
end

return Menu