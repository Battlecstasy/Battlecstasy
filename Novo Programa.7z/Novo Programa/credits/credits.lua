local Credits = {}
local nomes, botao, font1, font2

function Credits:new(fonte1, fonte2)
  nomes = {"ALEXANDRE HEINE", "BRENO ALBERIGI", "GABRIEL ROCHA", "HENRIQUE PERES", "MARCELO DRUMMOND", "ISABELLA RONCOLI"}
  botao = 3
  font1 = love.graphics.newFont(fonte1, 70)
  font2 = love.graphics.newFont(fonte2, 30)
end

function Credits:keyreleased(key)
  if key == "down" or key == "up" then
    botao = 0
    return 3
  elseif key == "return" and botao == 0 then
    return botao
  else
    return 3
  end
end

function Credits:mousereleased(button, mouseX, mouseY, prop, extraX, extraY)
  if botao == 0 and button == 1 and (mouseY>extraY+500*prop and mouseY<extraY+550*prop) and (mouseX>extraX+340*prop and mouseX<extraX+460*prop) then
    return botao
  else
    return 3
  end
end


function Credits:update(dt, mouseX, mouseX2, mouseY, mouseY2, prop, extraX, extraY)
  if (mouseX ~= mouseX2  and mouseY ~= mouseY2) then
    if (mouseY>extraY+500*prop and mouseY<extraY+550*prop) and(mouseX>extraX+340*prop and mouseX<extraX+460*prop)  then
      botao = 0
    else
      botao = 3
    end
  end
end

function Credits:draw(prop, extraX, extraY)
  love.graphics.setFont(font1, 70)
  love.graphics.print("Agradecimentos", extraX+200*prop, extraY+40*prop, 0, prop)
  love.graphics.setFont(font2, 30)
  for i = 1,6 do
    love.graphics.print(nomes[i], extraX+285*prop, extraY+(100+50*i)*prop, 0, prop)
  end
  love.graphics.rectangle("fill", extraX+340*prop, extraY+500*prop, 120*prop, 50*prop)
  love.graphics.setColor(0,0,0)
  love.graphics.print("VOLTAR", extraX+345*prop, extraY+510*prop, 0, prop)
  love.graphics.setColor(255,255,255)
  if botao == 0 then
    love.graphics.rectangle("line", extraX+330*prop, extraY+490*prop, 140*prop, 70*prop)
  end
end

return Credits