Raio = {}
local start, finish
function Raio:new()
  raio = {
  thunder = {love.graphics.newImage("Pikachu/Raio/raio1.png"), love.graphics.newImage("Pikachu/Raio/raio2.png"), love.graphics.newImage("Pikachu/Raio/raio3.png"), love.graphics.newImage("Pikachu/Raio/raio4.png"), love.graphics.newImage("Pikachu/Raio/raio5.png")},
  posY = 0,
  posMax = 230,
  variavel = 1,
  count = 0,
  count2 = 0,
  posX = 0
  }
  setmetatable(raio, { __index = Raio })
  return raio
end

--[[function Raio:variable()
  raio.variavel = 1
  return raio.variavel
end]]


function Raio:update(dt, pkX, translationX) -- pkX é usado para termos a posição do Pikachu, translationX para a direção que ele está virado e xAxis para
                                                   -- que o centro base em x do raio seja no centro da imagem do Pikachu
  raio.posX = pkX+(150*translationX)
   --if (love.keyboard.isDown("space")) then
   -- while raio.variavel <= 5 do
      if (raio.posX <= 0) then-- O ataque não passa os limites do mapa!
        raio.posX = 25
      elseif (raio.posX >= 775) then
        raio.posX = 775
      end
    
      if (raio.posY < raio.posMax) then -- fica variando entre 2 imagens do raio para dar um efeito eletrico
        raio.posY=raio.posY+(500*dt)
        if (raio.variavel == 1 and raio.count2%10==0) then
          raio.variavel = 2
        elseif (raio.variavel == 2 and raio.count2%10==5) then
          raio.variavel = 1
        end
        raio.count2 = raio.count2+1
      end
  
      if (raio.posY >= raio.posMax) then -- varia entre as 3 imagens de dissipacao do raio ao chegar chao
        if (raio.count < 15) then
          if (raio.count == 0) then -- ajusta a posicao da imagem
            raio.posX = raio.posX-10
          end
          raio.variavel = 3
        elseif (raio.count >= 15 and raio.count < 30) then
          if (raio.count == 15) then
            raio.posX = raio.posX-10 -- ajusta a posicao da imagem
          end
          raio.variavel = 4
        elseif (raio.count >= 30 and raio.count < 45)  then
          raio.variavel = 5
        elseif (raio.count >= 45) then
          raio.variavel = 1 -- trocar para 6 depois
          raio.posY = 0
          raio.count = 0
        end
        raio.count = raio.count + 1
      end
    --end
    --raio.variavel = 1
  --end  
  
end

function Raio:draw(xAxis)
    love.graphics.draw(raio.thunder[raio.variavel], raio.posX, raio.posY, 0, 1, 1, xAxis, 0)
end