local Character_Selection = {}
local cs_image, cs_player, cs_char, cs_name, cs_font, cs_voltar, cs, cs_botao

function Character_Selection:new(fonte1, fonte3)
  cs = "char_selection/"
  cs_botao = {1,8}
  cs_image = love.graphics.newImage(cs.."backgroundnovo.png")
  cs_voltar = love.graphics.newImage(cs.."voltar.png")
  cs_name = {110, 190}
  -- INICIALIZANDO A SEMI-MATRIZ PARA O JOGADOR
  cs_count = 0
  cs_player = {}
  for i=1,3 do
    if (i<3) then
      cs_player[i] = {}
      for j=1,2 do
        cs_player[i][j]=love.graphics.newImage(cs.."player"..i..j..".png")
      end
    else
      cs_player[i]=love.graphics.newImage(cs.."player"..i..".png")
    end
  end
  --INICIALIZANDO A MATRIZ DE PERSONAGENS
  cs_char = {}
  for i=1,4 do
    cs_char[i] = {}
    for j=1,2 do
      cs_char[i][j] = love.graphics.newImage(cs.."char"..i..j..".png")
    end
  end
  -- SETANDO AS FONTES
  cs_font = {love.graphics.setNewFont(fonte3, 15), love.graphics.setNewFont(fonte1, 40), love.graphics.setNewFont(fonte1, 25), love.graphics.setNewFont(fonte3, 10)}
end

function Character_Selection:keyreleased(key)
  if key == "d" then

  end
end

function Character_Selection:mousereleased()

end

function Character_Selection:update()

end

function Character_Selection:characterNumber()

end

function Character_Selection:draw(prop, extraX, extraY)
  love.graphics.setFont(cs_font[1])
  -- -- -- -- -- -- IMAGENS -- -- -- -- -- -- -- --
  love.graphics.draw(cs_image, extraX, extraY, 0, prop)

  for i=1,2 do
    love.graphics.draw(cs_player[i][1], extraX+(200*i-150)*prop, extraY+290*prop, 0, prop) -- RET MAIOR
    love.graphics.draw(cs_player[i][2], extraX+(200*i-180)*prop, extraY+251*prop, 0, prop) -- RET DE TEXTO
    love.graphics.print("JOGADOR "..i, extraX+(200*i-179)*prop, extraY+260*prop, 0, prop) -- TEXTO DO RET ANTERIOR
    love.graphics.draw(cs_player[3], extraX+(200*i-164)*prop, extraY+440*prop, 0, prop) -- BOTAO CONFIRMAR
  end

  love.graphics.draw(cs_voltar, extraX, extraY+44*prop, 0, prop)

  for i=1,4 do
    for j=1,2 do
      love.graphics.draw(cs_char[i][j], extraX+(150+80*i)*prop, extraY+(80*j-30)*prop, 0, 1.5*prop)
    end
  end
-- -- -- ESCOLHA DO PLAYER 1 -- -- -- A posicao Y está errada
love.graphics.setColor(255,0,0)
  love.graphics.rectangle("line", extraX+(150+80*(((cs_botao[1]-1)%4)+1))*prop, extraY+(80*(math.floor((cs_botao[1])/5)+1)-30)*prop, 1.5*cs_char[((cs_botao[1]-1)%4)+1][((cs_botao[1]-1)%2)+1]:getWidth()*prop, 1.5*cs_char[((cs_botao[1]-1)%4)+1][((cs_botao[1]-1)%2)+1]:getHeight()*prop, 20)
-- -- -- ESCOLHA DO PLAYER 2 -- -- --
love.graphics.setColor(0,0,255)
love.graphics.rectangle("line", extraX+(150+80*(((cs_botao[2]-1)%4)+1))*prop, extraY+(80*(math.floor((cs_botao[2])/5)+1)-30)*prop, 1.5*cs_char[((cs_botao[2]-1)%4)+1][((cs_botao[2]-1)%2)+1]:getWidth()*prop, 1.5*cs_char[((cs_botao[2]-1)%4)+1][((cs_botao[2]-1)%2)+1]:getHeight()*prop, 20)
love.graphics.setColor(255,255,255)
  -- -- -- -- -- -- TEXTO -- -- -- -- -- -- -- -- --
  love.graphics.setFont(cs_font[2])
  love.graphics.print("ESCOLHA DE PERSONAGEM", extraX+50*prop, extraY+5*prop, 0, prop)
  love.graphics.setFont(cs_font[3])
  love.graphics.print("VOLTAR", extraX+50*prop, extraY+93*prop, 0, prop)
  love.graphics.setFont(cs_font[4])
  love.graphics.print("Chun-Li", extraX+240*prop, extraY+cs_name[1]*prop, 0, prop)
  love.graphics.print("Cirno", extraX+327*prop, extraY+cs_name[1]*prop, 0, prop)
  love.graphics.print("Dio", extraX+415*prop, extraY+cs_name[1]*prop, 0, prop)
  love.graphics.print("Morgiana", extraX+474*prop, extraY+cs_name[1]*prop, 0, prop)
  love.graphics.print("Ky Kiske", extraX+236*prop, extraY+cs_name[2]*prop, 0, prop)
  love.graphics.print("Bowser", extraX+320*prop, extraY+cs_name[2]*prop, 0, prop)
  love.graphics.print("Popeye", extraX+400*prop, extraY+cs_name[2]*prop, 0, prop)
  love.graphics.print("Archer", extraX+480*prop, extraY+cs_name[2]*prop, 0, prop)
end

return Character_Selection