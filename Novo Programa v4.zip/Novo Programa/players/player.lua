local Player = {}
local player, p_matrizhelp
-- p_matrizhelp ajuda a colocar valores dentro de player sem necessitar de condicionais
function Player:new(p1, p2)
  player = {}
  p_matrizhelp = {p1, p2, 1, -1}
  
  for i=1,2 do
    player[i] = {persNum = p_matrizhelp[i], pers, persImg, lifebar = 100, superbar = 0, side = p_matrizhelp[i+2]}
    player[i].pers = require("characters/char"..player[i].persNum)
    player[i].persImg = love.graphics.newImage("characters/char"..player[i].persNum..".png")
  end
  
end

--[[function Player:update()
  for i=1,2 do
    player[i].pers:update()
  end
end

function Player:keypressed()
  for i=1,2 do
    player[i].pers:keypressed()
  end]]

function Player:draw(prop, extraX, extraY)
  for i=1,2 do
  --  player[i].pers:draw()
    love.graphics.draw(player[i].persImg, extraX+(50+(i-1)*650)*prop, extraY+50*prop, 0 , prop)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("fill", 50, 100, 300, 25)
    love.graphics.setColor(0,255,0)
    love.graphics.rectangle("fill", 50, 100, 300, 25)
    love.graphics.setColor(255,255,255)
  end
  
end

return Player